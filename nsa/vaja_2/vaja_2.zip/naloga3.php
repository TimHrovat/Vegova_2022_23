<?php
    $x=25; $y="a";

    echo "$x $y"."<br/>";

    echo '$x $y'.'<br/>';

    echo '$x + $y'.'<br/>';

    echo "$x + $y"."<br/>";

    $y = 30;
    echo $x + $y.'<br/>';

    $z="30";
    echo $x + $z.'<br/>';

    $t="30g";
    echo $x + $t.'<br/>';
?>

// '' ==> plain text 
// "" ==> lahko vpišemo spremenljivke, operacije se lahko izvajajo...

// kot int