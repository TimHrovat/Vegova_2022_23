<?php
    $x=30;
    echo '<p> Variatna 1 s piko </p>';

    echo 'opis: '.var_dump($x).'<br/>';

    echo '<p> Variatna 2 z vejico </p>';

    echo 'opis:',var_dump($x),'<br/>';

    echo '<p> Variatna 3 kombinacija vejica, pika</p>';

    echo 'opis: ',var_dump($x).'<br/>';

    echo '<p> Variatna 4 kombinacija pika, vejica</p>';

    echo 'opis: '.var_dump($x),'<br/>';
?>

// , izpiše izraze enega za drugim
// . izračuna vrednosti spremenljivk, pretvori vse v string in nato izpiše (traja dlje)